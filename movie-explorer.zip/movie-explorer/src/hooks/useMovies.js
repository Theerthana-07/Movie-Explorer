import { useEffect, useState } from "react";
import { friendlyError, getMovies } from "../api.js";

// Loads a category or search result list with "load more" pagination.
export default function useMovies(category, query) {
  const [req, setReq] = useState({ category, query, page: 1 });
  const [movies, setMovies] = useState([]);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // When the filter changes, restart from page 1 (state adjusted during render)
  if (req.category !== category || req.query !== query) {
    setReq({ category, query, page: 1 });
  }

  useEffect(() => {
    let ignore = false; // stops an old response from overwriting a newer one
    setLoading(true);
    setError("");
    getMovies(req)
      .then((data) => {
        if (ignore) return;
        setMovies((prev) => (req.page === 1 ? data.results : [...prev, ...data.results]));
        setTotalPages(data.total_pages);
      })
      .catch((e) => !ignore && setError(friendlyError(e)))
      .finally(() => !ignore && setLoading(false));
    return () => { ignore = true; };
  }, [req]);

  return {
    movies,
    loading,
    error,
    hasMore: req.page < totalPages,
    loadMore: () => setReq((r) => ({ ...r, page: r.page + 1 })),
    retry: () => setReq((r) => ({ ...r })),
  };
}
