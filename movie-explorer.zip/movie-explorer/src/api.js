// TMDB API layer. Get a free key at https://www.themoviedb.org/settings/api
const BASE = "https://api.themoviedb.org/3";
const KEY = import.meta.env.VITE_TMDB_KEY;

async function request(path, params = {}) {
  if (!KEY || KEY.startsWith("paste_")) {
    throw new Error("Missing API key. Add VITE_TMDB_KEY to your .env file and restart the dev server.");
  }
  const qs = new URLSearchParams({ api_key: KEY, language: "en-US", ...params });
  const res = await fetch(`${BASE}${path}?${qs}`);
  if (res.status === 401) throw new Error("The API key was rejected. Check VITE_TMDB_KEY in your .env file.");
  if (res.status === 404) throw new Error("That movie could not be found.");
  if (!res.ok) throw new Error(`Request failed (${res.status}). Please try again.`);
  return res.json();
}

export const CATEGORIES = [
  { id: "popular", label: "Popular" },
  { id: "top_rated", label: "Top rated" },
  { id: "now_playing", label: "Now playing" },
  { id: "upcoming", label: "Upcoming" },
];

export const getMovies = ({ category, query, page }) =>
  query ? request("/search/movie", { query, page }) : request(`/movie/${category}`, { page });

export const getMovie = (id) => request(`/movie/${id}`, { append_to_response: "credits" });

export const posterUrl = (path, size = "w342") => (path ? `https://image.tmdb.org/t/p/${size}${path}` : null);

// fetch() throws TypeError when offline
export const friendlyError = (e) =>
  e instanceof TypeError ? "Network problem. Check your internet connection and try again." : e.message;
