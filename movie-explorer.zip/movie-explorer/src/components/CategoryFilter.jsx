import { CATEGORIES } from "../api.js";

export default function CategoryFilter({ active, onSelect }) {
  return (
    <div className="filters" role="group" aria-label="Movie categories">
      {CATEGORIES.map((c) => (
        <button key={c.id} aria-pressed={active === c.id} onClick={() => onSelect(c.id)}>
          {c.label}
        </button>
      ))}
    </div>
  );
}
