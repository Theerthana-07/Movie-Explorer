export default function SearchBar({ value, onChange }) {
  return (
    <div className="search">
      <label htmlFor="q" className="sr">Search movies</label>
      <input
        id="q"
        type="search"
        placeholder="Search movies, e.g. Inception"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        autoComplete="off"
      />
    </div>
  );
}
