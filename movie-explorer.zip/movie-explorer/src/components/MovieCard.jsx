import { Link } from "react-router-dom";
import { posterUrl } from "../api.js";
import Rating from "./Rating.jsx";

export default function MovieCard({ movie }) {
  const img = posterUrl(movie.poster_path);
  const year = movie.release_date ? movie.release_date.slice(0, 4) : "TBA";
  return (
    <Link to={`/movie/${movie.id}`} className="card">
      {img ? <img src={img} alt={`${movie.title} poster`} loading="lazy" /> : <div className="noimg">No poster</div>}
      <div className="card-body">
        <h3>{movie.title}</h3>
        <div className="row">
          <span>{year}</span>
          <Rating value={movie.vote_average} votes={movie.vote_count} />
        </div>
      </div>
    </Link>
  );
}
