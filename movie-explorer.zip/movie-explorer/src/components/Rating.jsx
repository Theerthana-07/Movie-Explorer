// Shows TMDB's 0-10 vote average as a coloured badge.
export default function Rating({ value, votes }) {
  if (!votes) return <span className="rating none">No ratings</span>;
  const tone = value >= 7 ? "high" : value >= 5 ? "mid" : "low";
  return (
    <span className={`rating ${tone}`} aria-label={`Rated ${value.toFixed(1)} out of 10`}>
      ★ {value.toFixed(1)}
    </span>
  );
}
