import { Link, Route, Routes } from "react-router-dom";
import Home from "./pages/Home.jsx";
import MovieDetails from "./pages/MovieDetails.jsx";

export default function App() {
  return (
    <>
      <header className="site-header">
        <div className="wrap">
          <Link to="/" className="brand">Movie Explorer</Link>
        </div>
      </header>
      <main className="wrap">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/movie/:id" element={<MovieDetails />} />
          <Route path="*" element={<p className="state">Page not found. <Link to="/">Go home</Link></p>} />
        </Routes>
      </main>
      <footer className="wrap foot">
        Data from <a href="https://www.themoviedb.org/" rel="noopener">TMDB</a>. This product uses the TMDB API but is not endorsed or certified by TMDB.
      </footer>
    </>
  );
}
