import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import SearchBar from "../components/SearchBar.jsx";
import CategoryFilter from "../components/CategoryFilter.jsx";
import MovieCard from "../components/MovieCard.jsx";
import Loader from "../components/Loader.jsx";
import ErrorMessage from "../components/ErrorMessage.jsx";
import useDebounce from "../hooks/useDebounce.js";
import useMovies from "../hooks/useMovies.js";

export default function Home() {
  // Category and search live in the URL, so Back from a movie page keeps your place
  const [params, setParams] = useSearchParams();
  const category = params.get("category") || "popular";
  const query = params.get("q") || "";

  const [text, setText] = useState(query);
  const debounced = useDebounce(text.trim(), 500);

  useEffect(() => {
    setParams(
      (prev) => {
        const next = new URLSearchParams(prev);
        if (debounced) next.set("q", debounced);
        else next.delete("q");
        return next;
      },
      { replace: true }
    );
  }, [debounced, setParams]);

  const { movies, loading, error, hasMore, loadMore, retry } = useMovies(category, query);

  const selectCategory = (id) => {
    setText("");
    setParams({ category: id });
  };

  return (
    <>
      <h1>Find your next movie</h1>
      <SearchBar value={text} onChange={setText} />
      <CategoryFilter active={query ? "" : category} onSelect={selectCategory} />
      {query && <p className="note">Showing results for "{query}"</p>}

      {error && <ErrorMessage message={error} onRetry={retry} />}
      {!error && !loading && movies.length === 0 && (
        <p className="state">No movies found. Try a different title.</p>
      )}

      <div className="grid">
        {movies.map((m) => <MovieCard key={m.id} movie={m} />)}
      </div>

      {loading && <Loader />}
      {!loading && !error && hasMore && (
        <button className="more" onClick={loadMore}>Load more</button>
      )}
    </>
  );
}
