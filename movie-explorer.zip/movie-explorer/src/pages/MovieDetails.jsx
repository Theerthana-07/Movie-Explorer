import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { friendlyError, getMovie, posterUrl } from "../api.js";
import Loader from "../components/Loader.jsx";
import ErrorMessage from "../components/ErrorMessage.jsx";
import Rating from "../components/Rating.jsx";

export default function MovieDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [movie, setMovie] = useState(null);
  const [error, setError] = useState("");
  const [tries, setTries] = useState(0);

  useEffect(() => {
    let ignore = false;
    setMovie(null);
    setError("");
    getMovie(id)
      .then((m) => !ignore && setMovie(m))
      .catch((e) => !ignore && setError(friendlyError(e)));
    return () => { ignore = true; };
  }, [id, tries]);

  // Go back if there is history inside the app, otherwise go home
  const goBack = () => (window.history.state?.idx > 0 ? navigate(-1) : navigate("/"));
  const back = <button className="back" onClick={goBack}>&larr; Back</button>;

  if (error) return <>{back}<ErrorMessage message={error} onRetry={() => setTries((t) => t + 1)} /></>;
  if (!movie) return <>{back}<Loader label="Loading movie..." /></>;

  const img = posterUrl(movie.poster_path, "w500");
  const cast = movie.credits?.cast?.slice(0, 6) ?? [];
  const director = movie.credits?.crew?.find((p) => p.job === "Director");

  return (
    <>
      {back}
      <article className="detail">
        {img ? <img src={img} alt={`${movie.title} poster`} /> : <div className="noimg big">No poster</div>}
        <div>
          <h1>{movie.title}</h1>
          {movie.tagline && <p className="tagline">{movie.tagline}</p>}
          <p className="meta">
            <Rating value={movie.vote_average} votes={movie.vote_count} />
            <span>{movie.release_date?.slice(0, 4) || "TBA"}</span>
            {movie.runtime > 0 && <span>{Math.floor(movie.runtime / 60)}h {movie.runtime % 60}m</span>}
            {movie.vote_count > 0 && <span>{movie.vote_count.toLocaleString()} votes</span>}
          </p>
          <ul className="genres">{movie.genres.map((g) => <li key={g.id}>{g.name}</li>)}</ul>
          <h2>Overview</h2>
          <p>{movie.overview || "No overview available."}</p>
          {director && <p><strong>Director:</strong> {director.name}</p>}
          {cast.length > 0 && <p><strong>Cast:</strong> {cast.map((c) => c.name).join(", ")}</p>}
        </div>
      </article>
    </>
  );
}
