# Movie Explorer (React)

Search and browse movies using the TMDB public API.

## Features
- Search movies (debounced, so the API is not called on every keystroke)
- Category filters: Popular, Top rated, Now playing, Upcoming
- Movie details page: overview, runtime, genres, director, cast
- Ratings shown as coloured badges (green 7+, amber 5-7, red below 5)
- Loading indicators, error handling with retry, "Load more" pagination
- Responsive grid; filters and search saved in the URL so Back keeps your place

## Setup
1. Install Node.js 18 or newer.
2. Create a free account at themoviedb.org, then go to Settings > API and copy your **API Key (v3 auth)**.
3. In this folder:
   ```
   npm install
   copy .env.example .env      (Windows)   or   cp .env.example .env   (Mac/Linux)
   ```
4. Open `.env` and replace the placeholder with your key.
5. Run `npm run dev` and open the address it prints (usually http://localhost:5173).

## Build and deploy
`npm run build` creates a `dist` folder. Deploy options:
- **Vercel / Netlify:** import the GitHub repo and add `VITE_TMDB_KEY` as an environment variable.
- **GitHub Pages:** upload the `dist` contents (the app uses HashRouter and `base: "./"`, so it works on a sub-path).

Note: a key used in a front-end app is visible in the browser. This is normal for TMDB's read-only API; never commit `.env`.

## Structure
```
src/
  api.js                 API calls, categories, error messages
  hooks/useDebounce.js   delays a changing value
  hooks/useMovies.js     fetching, pagination, race-condition guard
  components/            SearchBar, CategoryFilter, MovieCard, Rating, Loader, ErrorMessage
  pages/Home.jsx         search + filters + grid
  pages/MovieDetails.jsx details route (/movie/:id)
```

## Concepts practised
Components and props, hooks (useState, useEffect, useSearchParams, useParams, custom hooks), API integration, state management, React Router.

## Suggested commits
- `chore: scaffold Vite React project`
- `feat: add TMDB api layer and movie grid`
- `feat: add debounced search and category filters`
- `feat: add movie details route`
- `feat: add loading and error states`
- `style: make layout responsive`
- `docs: add setup instructions`
